file(REMOVE_RECURSE
  "CMakeFiles/unitdom2.dir/unitdom2.cc.o"
  "CMakeFiles/unitdom2.dir/unitdom2.cc.o.d"
  "unitdom2"
  "unitdom2.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/unitdom2.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
