file(REMOVE_RECURSE
  "CMakeFiles/unitdom.dir/unitdom.cc.o"
  "CMakeFiles/unitdom.dir/unitdom.cc.o.d"
  "unitdom"
  "unitdom.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/unitdom.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
