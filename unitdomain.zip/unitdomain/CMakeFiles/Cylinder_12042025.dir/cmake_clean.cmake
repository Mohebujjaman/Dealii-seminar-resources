file(REMOVE_RECURSE
  "CMakeFiles/Cylinder_12042025.dir/Cylinder_12042025.cc.o"
  "CMakeFiles/Cylinder_12042025.dir/Cylinder_12042025.cc.o.d"
  "Cylinder_12042025"
  "Cylinder_12042025.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/Cylinder_12042025.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
