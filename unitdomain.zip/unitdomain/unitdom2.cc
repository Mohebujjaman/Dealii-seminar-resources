/* ---------------------------------------------------------------------
 *
 * Copyright (C) 2008 - 2014 by the deal.II authors
 *
 * This file is part of the deal.II library.
 *
 * The deal.II library is free software; you can use it, redistribute
 * it, and/or modify it under the terms of the GNU Lesser General
 * Public License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * The full text of the license can be found in the file LICENSE at
 * the top level of the deal.II distribution.
 *
 * ---------------------------------------------------------------------

 *
 * 
   Author: Mohebujjaman (Navier-Stokes Equations) 
   Date: 05/22/2026
   University of Alabama at Birmingham
 */


// @sect3{Include files}

// As usual, we start by including some well-known files:
#include <deal.II/base/quadrature_lib.h>
#include <deal.II/base/logstream.h>
#include <deal.II/base/function.h>
#include <deal.II/base/utilities.h>
#include <deal.II/base/timer.h>

#include <deal.II/lac/block_vector.h>
#include <deal.II/lac/full_matrix.h>
#include <deal.II/lac/block_sparse_matrix.h>
#include <deal.II/lac/solver_cg.h>
#include <deal.II/lac/precondition.h>
//#include <deal.II/lac/constraint_matrix.h>

#include <deal.II/lac/affine_constraints.h>

#include <deal.II/grid/tria.h>
#include <deal.II/grid/grid_generator.h>
#include <deal.II/grid/tria_accessor.h>
#include <deal.II/grid/tria_iterator.h>
//#include <deal.II/grid/tria_boundary_lib.h>
#include <deal.II/grid/grid_tools.h>
#include <deal.II/grid/grid_refinement.h>
#include <deal.II/grid/grid_in.h>
#include <deal.II/grid/grid_out.h>

#include <deal.II/dofs/dof_handler.h>
#include <deal.II/dofs/dof_renumbering.h>
#include <deal.II/dofs/dof_accessor.h>
#include <deal.II/dofs/dof_tools.h>

#include <deal.II/fe/fe_q.h>
#include <deal.II/fe/fe_system.h>
#include <deal.II/fe/fe_values.h>
#include <time.h>

#include <deal.II/numerics/vector_tools.h>
#include <deal.II/numerics/matrix_tools.h>
#include <deal.II/numerics/data_out.h>
#include <deal.II/numerics/error_estimator.h>
#include <deal.II/base/convergence_table.h>
// Then we need to include the header file for the sparse direct solver
// UMFPACK:
#include <deal.II/lac/sparse_direct.h>

// This includes the library for the incomplete LU factorization that will be
// used as a preconditioner in 3D:
#include <deal.II/lac/sparse_ilu.h>

// This is C++:
#include <fstream>
#include <sstream>
#include <deal.II/base/parameter_handler.h>
//#include <random>


// As in all programs, the namespace dealii is included:
namespace NSE
{
  using namespace dealii;

  namespace RunTimeParameters
  {
     class Data_Storage
     {

     public:

       Data_Storage();
       ~Data_Storage();
       void read_data(const char *filename);

        double final_time,
              viscosity,
              time_step,
              mu,
              epsilon,
              gamma;

       unsigned int Number_of_refinements,
                    pressure_degree,
                    numTimeSteps,
                    Number_of_realizations;

     protected:
       ParameterHandler prm;
     };


     Data_Storage::Data_Storage()
      {
         prm.enter_subsection ("Mesh & geometry parameters");
         {
           prm.declare_entry("Number_of_refinements", "1",
                        Patterns::Integer (0, 15),
                        "The number of global refines we do on the mesh.");

           prm.declare_entry("pressure_fe_degree","1",
                        Patterns::Integer (1, 5),
                        "The polynomial degree for the pressure space.");
          }

          prm.leave_subsection ();

          prm.enter_subsection ("Physical constants");
          {

            prm.declare_entry("final_time", "0.01",
                        Patterns::Double(0),
                        "Simulation Time");

            prm.declare_entry("expected_viscosity", "0.001",
                        Patterns::Double(0),
                        "expected_viscosity");



            //prm.declare_entry("number_of_time_steps", "10",
            //            Patterns::Double(0),
            //            "Total Number of Time Steps Used");

            prm.declare_entry("time_step", "0.0001",
                        Patterns::Double(0),
                        "Time Step Size");

            prm.declare_entry("epsilon","0.1",
                        Patterns::Double(0),
                        "The Perturbation Parameter");

            prm.declare_entry("mu","0.1",
                        Patterns::Double(0),
                        "The Tuning Parameter");

            prm.declare_entry("gamma","1000.0",
                        Patterns::Double(0),
                        "Grad-div stabilization Parameter");

            /*prm.declare_entry("Number_of_realizations","1",
                        Patterns::Integer (0, 100),
                        "Number_of_realizations.");*/

           }

           prm.leave_subsection ();

      }

     Data_Storage::~Data_Storage()
    {}

     void Data_Storage::read_data(const char *filename)
      {
         std::ifstream file (filename);
         AssertThrow (file, ExcFileNotOpen (filename));

         prm.parse_input (file);

         prm.enter_subsection ("Physical constants");
         {
             final_time = prm.get_double ("final_time");
            viscosity = prm.get_double ("expected_viscosity");
            time_step = prm.get_double("time_step");
            //numTimeSteps = prm.get_integer("number_of_time_steps");
            epsilon = prm.get_double("epsilon");
            mu = prm.get_double("mu");
            gamma = prm.get_double("gamma");
            //Number_of_realizations = prm.get_integer("Number_of_realizations");

          }

         prm.leave_subsection ();

         prm.enter_subsection ("Mesh & geometry parameters");
          {
             Number_of_refinements = prm.get_integer("Number_of_refinements");
             pressure_degree = prm.get_integer("pressure_fe_degree");
           }

         prm.leave_subsection ();

        }

  }

  /***********************
        * Initial condition class */

    template <int dim>
    class InitialCondition : public Function<dim>
    {
      public:
       InitialCondition (const unsigned int id = 1) : Function<dim>(dim+1)
       , id_number(id) {}
      virtual void vector_value (const Point<dim> &p,
                             Vector<double>   &value) const override;

    private:
      unsigned int id_number;
    };


    template <int dim>
    void InitialCondition<dim>::vector_value (const Point<dim> &p, Vector<double>   &values) const
    {
     Assert (values.size() == dim+1, ExcDimensionMismatch (values.size(), dim+1));
     double x = p[0];
     double y = p[1];
     double t = this->get_time();
     //static const double PI = 3.14159265358979323846;
     //std::cout<<"Time = "<<t<<std::endl;
     values(0) = id_number*(cos(y)+(1.0+exp(t))*sin(y));
     values(1) = id_number*(sin(x)+(1.0+exp(t))*cos(x));
     values(2) = 1.0*sin(x+y)*(1.0+exp(t));
    }

  namespace EquationData{

    template <int dim>
    class ZeroFxn : public Function<dim>
    {
      public:
      ZeroFxn () : Function<dim>(dim+1) {}

      virtual double value (const Point<dim>   &p,
                          const unsigned int  component = 0) const override;

      virtual void vector_value (const Point<dim> &p,
                               Vector<double>   &value) const override;

      };


    template <int dim>
    double  ZeroFxn<dim>::value (const Point<dim>  & /* p */,
                              const unsigned int component) const
      {

       Assert (component < this->n_components,
            ExcIndexRange (component, 0, this->n_components));

       return 0;

      }


     template <int dim>
    void  ZeroFxn<dim>::vector_value (const Point<dim> &p, Vector<double>   &values) const
    {
       for (unsigned int c=0; c<this->n_components; ++c)
        values(c) = ZeroFxn<dim>::value (p, c);
     }


  // We implement similar functions for the right hand side:

  template <int dim>


     class RightHandSide : public Function<dim>

     {
     public:
       RightHandSide () : Function<dim>(dim+1) {}

     
     virtual double value (const Point<dim>   &p,
                        const unsigned int  component = 0) const override;
     virtual void vector_value (const Point<dim> &p,
                             Vector<double>   &value) const override;

     };


    template <int dim>
    double  RightHandSide<dim>::value (const Point<dim>  & /* p */, 
				const unsigned int /* component */) const
    {
	return 0;
    }


    template <int dim>
    void  RightHandSide<dim>::vector_value (const Point<dim> &p, Vector<double>   &values) const
    {
       for (unsigned int c=0; c<this->n_components; ++c)
            values(c) = RightHandSide<dim>::value (p, c);
    }

   }


  template <int dim>
  class NavierStokesProblem
  {
    public:
    NavierStokesProblem (const Function<dim> &initial_condition, const RunTimeParameters::Data_Storage &data);

    void run ();


    private:
    const double T;
    const unsigned int n_global_refines;
    const unsigned int degree;

    double viscosity;

    void setup_dofs ();
    void assemble_system_1st_order (double viscosity); 
    void assemble_system_RHS_1st_order ();
    void assemble_system_2nd_order (double viscosity); 
    void assemble_system_RHS_2nd_order ();
    void implement_boundary_condition (); 

    void solve ();
    void output_results (const unsigned int refinement_cycle) const;
    void refine_mesh ();
    void Energy (double t);

    void print_mesh_info(const Triangulation<dim> &tria, const std::string     &filename);

    std::vector<types::boundary_id> boundary_ids;

    Triangulation<dim>   triangulation;
    FESystem<dim>        fe;
    DoFHandler<dim>      dof_handler;

    AffineConstraints<double>    constraints;

    BlockSparsityPattern      sparsity_pattern;
    BlockSparseMatrix<double> system_matrix;


    BlockVector<double> old_timestep_solution;
    BlockVector<double> old_old_timestep_solution;
    BlockVector<double> solution;


    BlockVector<double> present_solution;

    BlockVector<double> system_rhs;

    
    EquationData::RightHandSide<dim>  right_hand_side;
    EquationData::ZeroFxn<dim> zero_fxn;

    const Function<dim> &initial_condition;
    

    double time, time_step;
    unsigned int timestep_number;
    
    double  gamma;
    FILE *pFile;
   };



  template <int dim>
  NavierStokesProblem<dim>::NavierStokesProblem (const Function<dim> &initial_condition, const RunTimeParameters::Data_Storage &data)
    :
    T (data.final_time),
    n_global_refines (data.Number_of_refinements),
    degree (data.pressure_degree),
    viscosity(data.viscosity),
    triangulation (Triangulation<dim>::maximum_smoothing),
    fe (FE_Q<dim>(degree+1), dim,
        FE_Q<dim>(degree), 1),
    dof_handler (triangulation),
    initial_condition(initial_condition),
    time_step (data.time_step),
    timestep_number(int(T/time_step)),
    gamma(data.gamma)

  {}

   
  template <int dim>
  void NavierStokesProblem<dim>::setup_dofs ()
  {
    //TimerOutput::Scope t(computing_timer, "setup_dofs");

    system_matrix.clear ();

    dof_handler.distribute_dofs (fe);


    std::vector<unsigned int> block_component (dim+1,0);
    block_component[dim] = 1;
    DoFRenumbering::component_wise (dof_handler, block_component);

    std::vector<types::global_dof_index> dofs_per_block=
    DoFTools::count_dofs_per_fe_block (dof_handler,  block_component);
    const unsigned int n_v = dofs_per_block[0],
                       n_p = dofs_per_block[1];

     std::cout << "   Number of active cells: "
              << triangulation.n_active_cells()
              << std::endl
              << "   Number of degrees of freedom: "
              << dof_handler.n_dofs()
              << " (" << n_v << '+' << n_p << ')'
              << std::endl;


   {
    BlockDynamicSparsityPattern csp (2,2);
          
    csp.block(0,0).reinit (n_v, n_v);
    csp.block(1,0).reinit (n_p, n_v);
    csp.block(0,1).reinit (n_v, n_p);
    csp.block(1,1).reinit (n_p, n_p);
          
    csp.collect_sizes();
          
    DoFTools::make_sparsity_pattern (dof_handler, csp, constraints, false);
    sparsity_pattern.copy_from (csp);
   }

   system_matrix.reinit (sparsity_pattern);

    solution.reinit (2);
    solution.block(0).reinit (n_v);
    solution.block(1).reinit (n_p);
    solution.collect_sizes ();

    old_old_timestep_solution.reinit (2);
    old_old_timestep_solution.block(0).reinit (n_v);
    old_old_timestep_solution.block(1).reinit (n_p);
    old_old_timestep_solution.collect_sizes ();

    old_timestep_solution.reinit (2);
    old_timestep_solution.block(0).reinit (n_v);
    old_timestep_solution.block(1).reinit (n_p);
    old_timestep_solution.collect_sizes ();

    

    present_solution.reinit (2);
    present_solution.block(0).reinit (n_v);
    present_solution.block(1).reinit (n_p);
    present_solution.collect_sizes ();


    

    system_rhs.reinit (2);
    system_rhs.block(0).reinit (n_v);
    system_rhs.block(1).reinit (n_p);
    system_rhs.collect_sizes ();
  }


  template <int dim>
  void NavierStokesProblem<dim>::assemble_system_1st_order (double viscosity)    
  {
   // TimerOutput::Scope t(computing_timer, "assemble_system_1st_order");
    system_matrix = 0;
    

    QGauss<dim>   quadrature_formula(degree+2);

    FEValues<dim> fe_values (fe, quadrature_formula,
                             update_values    |
                             update_quadrature_points  |
                             update_JxW_values |
                             update_gradients);

    const unsigned int   dofs_per_cell   = fe.dofs_per_cell;

    const unsigned int   n_q_points      = quadrature_formula.size();
    //std::cout<<"n_q_points= "<<n_q_points<<std::endl;

    FullMatrix<double>   local_matrix (dofs_per_cell, dofs_per_cell);
    

    std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

    
    const FEValuesExtractors::Vector velocities (0);
    const FEValuesExtractors::Scalar pressure (dim);

    
    //std::vector<SymmetricTensor<2,dim> > symgrad_phi_u (dofs_per_cell);
    std::vector<Tensor<2,dim> >             grad_phi_u (dofs_per_cell);
    std::vector<double>                      div_phi_u (dofs_per_cell);
    std::vector<double>                          phi_p (dofs_per_cell);
    std::vector<Tensor<1,dim> >                  phi_u (dofs_per_cell);
    
    std::vector<Tensor<1,dim> > old_time_u_values (n_q_points);
    

    //std::cout<<" Inside the system assembly"<<std::endl;

    typename DoFHandler<dim>::active_cell_iterator
    cell = dof_handler.begin_active(),
    endc = dof_handler.end();
    for (; cell!=endc; ++cell)
      {
        fe_values.reinit (cell);
        local_matrix = 0;
        

        fe_values[velocities].get_function_values(old_timestep_solution, old_time_u_values);
        
                
        for (unsigned int q=0; q<n_q_points; ++q)
          {
            for (unsigned int k=0; k<dofs_per_cell; ++k)
              {
                //symgrad_phi_u[k] = fe_values[velocities].symmetric_gradient (k, q);
                grad_phi_u[k]    = fe_values[velocities].gradient (k, q);
                div_phi_u[k]     = fe_values[velocities].divergence (k, q);
                phi_p[k]         = fe_values[pressure].value (k, q);
                phi_u[k]         = fe_values[velocities].value (k, q);
              }


            for (unsigned int i=0; i<dofs_per_cell; ++i)
              {
                
                for (unsigned int j=0; j<dofs_per_cell; ++j)
                  {

                    local_matrix(i,j) += ( phi_u[i]*phi_u[j]+time_step*viscosity*scalar_product(grad_phi_u[i],grad_phi_u[j])
                                          -time_step* div_phi_u[i] * phi_p[j]
                                          +time_step* gamma*div_phi_u[i]*div_phi_u[j]
                                          +1/2.0*time_step*grad_phi_u[j]* old_time_u_values[q]*phi_u[i]
                                          -1/2.0*time_step*grad_phi_u[i]* old_time_u_values[q]*phi_u[j]
                                          -time_step* phi_p[i]*div_phi_u[j])
                                         * fe_values.JxW(q);

                  }                      

              }
         }
        

        cell->get_dof_indices (local_dof_indices);

        for (unsigned int i=0; i<dofs_per_cell; ++i){
          for (unsigned int j=0; j<dofs_per_cell; ++j){
            system_matrix.add(local_dof_indices[i],local_dof_indices[j],local_matrix(i,j));
          }

        }

        
      }
  }

  template <int dim>
  void NavierStokesProblem<dim>::assemble_system_RHS_1st_order () 
  {
   // TimerOutput::Scope t(computing_timer, "assemble_system_RHS_1st_order");
    system_rhs = 0;

    QGauss<dim>   quadrature_formula(degree+2);

    FEValues<dim> fe_values (fe, quadrature_formula,
                             update_values    |
                             update_quadrature_points  |
                             update_JxW_values |
                             update_gradients);

    const unsigned int   dofs_per_cell   = fe.dofs_per_cell;
    const unsigned int   n_q_points      = quadrature_formula.size();

    

    
    Vector<double>       local_rhs (dofs_per_cell);

    std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

    
    
    //std::cout<<"viscosity-assemble= "<<viscosity<<std::endl;

    std::vector<Vector<double> >      rhs_values (n_q_points, Vector<double>(dim+1));

    // Next, we need two objects that work as extractors for the FEValues
    // object. Their use is explained in detail in the report on @ref
    // vector_valued :

    const FEValuesExtractors::Vector velocities (0);
    const FEValuesExtractors::Scalar pressure (dim);
    

    
    
    std::vector<Tensor<2,dim> >             grad_phi_u (dofs_per_cell);
    std::vector<Tensor<1,dim> >                  phi_u (dofs_per_cell);
    std::vector<Tensor<1,dim> > old_time_u_values (n_q_points);
    



    typename DoFHandler<dim>::active_cell_iterator
    cell = dof_handler.begin_active(),
    endc = dof_handler.end();
    for (; cell!=endc; ++cell)
      {
        fe_values.reinit (cell);
        
        local_rhs = 0;

        right_hand_side.vector_value_list(fe_values.get_quadrature_points(),rhs_values);
        fe_values[velocities].get_function_values(old_timestep_solution, old_time_u_values);
        
        

        
        for (unsigned int q=0; q<n_q_points; ++q)
          {
            for (unsigned int k=0; k<dofs_per_cell; ++k)
              {
              phi_u[k]         = fe_values[velocities].value (k, q);
              }

          
            for (unsigned int i=0; i<dofs_per_cell; ++i)
              {
                

                const unsigned int component_i = fe.system_to_component_index(i).first;

                local_rhs(i) += ( time_step* fe_values.shape_value(i,q)* rhs_values[q](component_i)
                                  +old_time_u_values[q]*phi_u[i])*fe_values.JxW(q);

              }
          }
        

        cell->get_dof_indices (local_dof_indices);

        for (unsigned int i=0; i<dofs_per_cell; ++i){
          system_rhs(local_dof_indices[i]) += local_rhs(i);

        }

        
     }
  }



  template <int dim>
  void NavierStokesProblem<dim>::assemble_system_2nd_order (double viscosity)
  {
   // TimerOutput::Scope t(computing_timer, "assemble_system_2nd_order");
    system_matrix=0;
    

    QGauss<dim>   quadrature_formula(degree+2);

    FEValues<dim> fe_values (fe, quadrature_formula,
                             update_values    |
                             update_quadrature_points  |
                             update_JxW_values |
                             update_gradients);


    const unsigned int   dofs_per_cell   = fe.dofs_per_cell;

    const unsigned int   n_q_points      = quadrature_formula.size();

    FullMatrix<double>   local_matrix (dofs_per_cell, dofs_per_cell);

    std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

    const FEValuesExtractors::Vector velocities (0);
    const FEValuesExtractors::Scalar pressure (dim);

    std::vector<Tensor<2,dim> >             grad_phi (dofs_per_cell);
    std::vector<double>                      div_phi (dofs_per_cell);
    std::vector<double>                        phi_p (dofs_per_cell);
    std::vector<Tensor<1,dim> >                  phi (dofs_per_cell);

    std::vector<Tensor<1,dim> > old_time_values (n_q_points);
    std::vector<Tensor<2,dim> > old_gradients_values (n_q_points);

    std::vector<Tensor<1,dim> > old_old_time_values (n_q_points);
    std::vector<Tensor<2,dim> > old_old_gradients_values (n_q_points);
   
    
    typename DoFHandler<dim>::active_cell_iterator
    cell = dof_handler.begin_active(),
    endc = dof_handler.end();
    for (; cell!=endc; ++cell)
      {
       fe_values.reinit (cell);

       local_matrix = 0;

       fe_values[velocities].get_function_values(old_old_timestep_solution, old_old_time_values);
       //fe_values[velocity].get_function_gradients(old_old_timestep_solution, old_old_gradients_values);
       fe_values[velocities].get_function_values(old_timestep_solution, old_time_values);
       //fe_values[velocity].get_function_values(old_timestep_solution, old_time_values);
       //fe_values[velocity].get_function_gradients(old_timestep_solution, old_gradients_values);

       for (unsigned int q=0; q<n_q_points; ++q)
          {
            for (unsigned int k=0; k<dofs_per_cell; ++k)
              {
                grad_phi[k]    = fe_values[velocities].gradient (k, q);
                div_phi[k]     = fe_values[velocities].divergence (k, q);
                phi_p[k]       = fe_values[pressure].value (k, q);
                phi[k]         = fe_values[velocities].value (k, q);

              }

      
    


       for (unsigned int i=0; i<dofs_per_cell; ++i)
              {


                 for (unsigned int j=0; j<dofs_per_cell; ++j)
                  {
                         local_matrix(i,j) += (1.5 * phi[i]*phi[j]+time_step*viscosity*scalar_product(grad_phi[i], grad_phi[j])
                                          -time_step* div_phi[i] * phi_p[j]
                                          +time_step * gamma* div_phi[i] *div_phi[j]
                                          + time_step* grad_phi[j] * old_time_values[q]*phi[i]
                                          - time_step* grad_phi[i] * old_time_values[q]*phi[j]
                                          -0.5 * time_step* grad_phi[j] * old_old_time_values[q]*phi[i]
                                          +0.5 * time_step* grad_phi[i] * old_old_time_values[q]*phi[j]
                                          -time_step* phi_p[i]*div_phi[j])* fe_values.JxW(q);


                  }
            
                }


              }

              cell->get_dof_indices (local_dof_indices);

              for (unsigned int i=0; i<dofs_per_cell; ++i){
                for (unsigned int j=0; j<dofs_per_cell; ++j){
                  system_matrix.add(local_dof_indices[i],local_dof_indices[j],local_matrix(i,j));
                }
      
              }
      
              
            }
        }

    

        template <int dim>
        void NavierStokesProblem<dim>::assemble_system_RHS_2nd_order () 
        {
          //TimerOutput::Scope t(computing_timer, "assemble_system_RHS_2nd_order");
          system_rhs=0;
      
          QGauss<dim>   quadrature_formula(degree+2);
      
          FEValues<dim> fe_values (fe, quadrature_formula,
                                   update_values    |
                                   update_quadrature_points  |
                                   update_JxW_values |
                                   update_gradients);
      
        const unsigned int   dofs_per_cell   = fe.dofs_per_cell;
        const unsigned int   n_q_points      = quadrature_formula.size();

        Vector<double>       local_rhs (dofs_per_cell);

        std::vector<types::global_dof_index> local_dof_indices (dofs_per_cell);

        std::vector<Vector<double> >      rhs_values (n_q_points, Vector<double>(dim+1));


        const FEValuesExtractors::Vector velocities (0);
        const FEValuesExtractors::Scalar pressure (dim);

        std::vector<Tensor<2,dim> >             grad_phi (dofs_per_cell);
        //std::vector<double>                      div_phi (dofs_per_cell);
    //std::vector<double>                        phi_p (dofs_per_cell);
    std::vector<Tensor<1,dim> >                  phi (dofs_per_cell);

    std::vector<Tensor<1,dim> > old_time_values (n_q_points);
    std::vector<Tensor<2,dim> > old_gradients_values (n_q_points);

    std::vector<Tensor<1,dim> > old_old_time_values (n_q_points);
    std::vector<Tensor<2,dim> > old_old_gradients_values (n_q_points);

    typename DoFHandler<dim>::active_cell_iterator
    cell = dof_handler.begin_active(),
    endc = dof_handler.end();
    for (; cell!=endc; ++cell)
      {
        fe_values.reinit (cell);
        
        local_rhs = 0;

       right_hand_side.vector_value_list(fe_values.get_quadrature_points(),rhs_values);
       fe_values[velocities].get_function_values(old_old_timestep_solution, old_old_time_values);
       
       
       fe_values[velocities].get_function_values(old_timestep_solution, old_time_values);
       

       for (unsigned int q=0; q<n_q_points; ++q)
          {
            for (unsigned int k=0; k<dofs_per_cell; ++k)
              {
                grad_phi[k]    = fe_values[velocities].gradient (k, q);
                //div_phi[k]     = fe_values[velocities].divergence (k, q);
                //phi_p[k]       = fe_values[pressure].value (k, q);
                phi[k]         = fe_values[velocities].value (k, q);

              }

      for (unsigned int i=0; i<dofs_per_cell; ++i)
       {
                

        const unsigned int component_i = fe.system_to_component_index(i).first;

        local_rhs(i) += (time_step*fe_values.shape_value(i,q)* rhs_values[q](component_i)
                + 2.0*old_time_values[q]*phi[i] -0.5 * old_old_time_values[q]*phi[i])*fe_values.JxW(q);

              }
          }

        cell->get_dof_indices (local_dof_indices);

          for (unsigned int i=0; i<dofs_per_cell; ++i){
            system_rhs(local_dof_indices[i]) += local_rhs(i);
  
          }
  
          
       }
    }


  template <int dim>
  void NavierStokesProblem<dim>::solve ()
  {
   // TimerOutput::Scope t(computing_timer, "solve");
     //solution = 0;
     SparseDirectUMFPACK solver;
     solver.initialize (system_matrix);
     solver.vmult(solution,system_rhs);
     constraints.distribute (solution);

  }

  
  template <int dim>
  void NavierStokesProblem<dim>::print_mesh_info(const Triangulation<dim> &tria,
                     const std::string        &filename)
  {
  std::cout << "Mesh info:" << std::endl
            << " dimension: " << dim << std::endl
            << " no. of cells: " << tria.n_active_cells() << std::endl;
  {
    std::map<unsigned int, unsigned int> boundary_count;
    typename Triangulation<dim>::active_cell_iterator
    cell = tria.begin_active(),
    endc = tria.end();
    for (; cell!=endc; ++cell)
      {
        for (unsigned int face=0; face<GeometryInfo<dim>::faces_per_cell; ++face)
          {
            if (cell->face(face)->at_boundary())
              boundary_count[cell->face(face)->boundary_id()]++;
          }
      }
    //std::cout << " boundary indicators: ";
    for (std::map<unsigned int, unsigned int>::iterator it=boundary_count.begin();
         it!=boundary_count.end();
         ++it)
      {
        std::cout << it->first << "(" << it->second << " times) ";
      }
    std::cout << std::endl;
  }
  std::ofstream out (filename.c_str());
  GridOut grid_out;
  grid_out.write_eps (tria, out);
  std::cout << " written to " << filename
            << std::endl
            << std::endl;
 }


 template <int dim>
  void  NavierStokesProblem<dim>::Energy (double t)
  {
    //TimerOutput::Scope t(computing_timer, "energy");
    double energy_mean = 0.0;
    Vector<double> difference_per_cell (triangulation.n_active_cells());
    const ComponentSelectFunction<dim> velocities(std::make_pair(0, dim), dim+1); 

    VectorTools::integrate_difference (dof_handler,
                                     present_solution,
                                     Functions::ZeroFunction<dim>(dim+1),
                                     difference_per_cell,
                                     QGauss<dim>(4),
                                     VectorTools::H1_seminorm, &velocities);

    energy_mean = 0.5*difference_per_cell.l2_norm();
    fprintf (pFile, "%f  %f\n",t, energy_mean);
  }



  template <int dim>
  void  NavierStokesProblem<dim>::output_results (const unsigned int timestep_number)  const
  {
   // TimerOutput::Scope t(computing_timer, "output");
    std::vector<std::string> solution_names (dim, "velocity");
    solution_names.push_back ("pressure");

    std::vector<DataComponentInterpretation::DataComponentInterpretation>
    data_component_interpretation
    (dim, DataComponentInterpretation::component_is_part_of_vector);
    data_component_interpretation
    .push_back (DataComponentInterpretation::component_is_scalar);

    DataOut<dim> data_out;
    data_out.attach_dof_handler (dof_handler);
    data_out.add_data_vector (present_solution, solution_names,
                              DataOut<dim>::type_dof_data,
                              data_component_interpretation);
    data_out.build_patches ();

    std::ostringstream filename;
    filename << "solution-"
             << Utilities::int_to_string (timestep_number, 2)
             << ".vtk";

    std::ofstream output (filename.str().c_str());
    data_out.write_vtk (output);

  }


  template <int dim>
  void NavierStokesProblem<dim>::implement_boundary_condition()
  {

    //std::cout<<"inside Boundaries = " <<std::endl;

    std::vector<unsigned int> block_component (dim+1,0);
    block_component[dim] = 1;

    std::vector<types::global_dof_index> dofs_per_block=
    DoFTools::count_dofs_per_fe_block (dof_handler,  block_component);
    //const unsigned int n_v = dofs_per_block[0];

    const FEValuesExtractors::Vector velocities (0);
    const FEValuesExtractors::Scalar pressure (dim);
    constraints.clear ();
   

    
    VectorTools::interpolate_boundary_values (dof_handler,
                                      0,
                                      initial_condition,
                                      constraints,
                                      fe.component_mask(velocities));
        
    //constraints.add_line(n_v);
    constraints.close();

    constraints.condense(system_matrix, system_rhs);

  }


  template <int dim>
  void NavierStokesProblem<dim>::run ()
  {

      double viscosity=0.01;                                           
      

      pFile = fopen("energy.txt","w");

      //print the data
      std::cout<<"Problem Data:"<<std::endl;
      std::cout<<"--------------------------------------------------"<<std::endl;
      std::cout<<"--------------------------------------------------"<<std::endl;

      std::cout<<"viscosity = "<<viscosity<<std::endl;
      std::cout<<"gamma = "<<gamma<<std::endl;
      
      //std::cout<<"number of realization = "<<Number_of_realizations<<std::endl;
      std::cout<<"n_global_refines= "<<n_global_refines<<std::endl;

      std::cout<<"--------------------------------------------------"<<std::endl;
      std::cout<<"--------------------------------------------------"<<std::endl;

      

      GridGenerator::hyper_cube (triangulation, 0, 1);

      std::cout<<"n_global_refines= "<<n_global_refines<<std::endl;

      boundary_ids = triangulation.get_boundary_ids();

      print_mesh_info(triangulation, "grid-1.eps");
      triangulation.refine_global (n_global_refines);

      setup_dofs ();

      time = 0.0;
      
      old_old_timestep_solution = 0;
      present_solution = 0;

        
      VectorTools::interpolate(dof_handler, initial_condition, old_old_timestep_solution);
                      
      
      time = time_step*1;
      old_timestep_solution = 0;
      right_hand_side.set_time(time);
      zero_fxn.set_time(time);
      

      clock_t tStart = clock();

       
      old_timestep_solution = old_old_timestep_solution;

      assemble_system_1st_order (viscosity);
      assemble_system_RHS_1st_order ();
      implement_boundary_condition();

      solve ();

      old_timestep_solution = solution;

      

      
          
 
           for (unsigned int n=2; n<=timestep_number; ++n){
              time = time_step*n;
              right_hand_side.set_time(time);
              zero_fxn.set_time(time);
              

              present_solution.add(2,old_timestep_solution,-1,old_old_timestep_solution);
              output_results (n);
              Energy (time);
              present_solution = 0;

           
              std::cout<<"Current Time="<<time<<"  "<<"TimeStepNumer="<<n<<std::endl;
 
                
             
            // old_timestep_solution = Storage_n[j];
 
             //std::cout<<"assemble_system mean_viscosity= "<<mean_viscosity<<std::endl;
             assemble_system_2nd_order (viscosity);
 
             //std::cout<<"assemble_system_RHS for j="<<j<<std::endl;
             assemble_system_RHS_2nd_order ();
              
             //std::cout<<"Before in bc"<<std::endl; 
             implement_boundary_condition();
 
             //std::cout<<" Solving now"<<std::endl;                           
             solve ();

             old_old_timestep_solution = old_timestep_solution;
             old_timestep_solution = solution;
             }
        
              
         
         //computing_timer.print_summary();
         //computing_timer.reset();

         

         std::cout<<"Time taken: "<<(double)(clock() - tStart)/CLOCKS_PER_SEC<<std::endl;

         
 
         std::cout << std::endl;
         
         std:: cout<<"Total number of timestep= "<<timestep_number<<std::endl;
 
 
   }
 }

 int main ()
 {
   try
     {
       using namespace dealii;
       using namespace NSE;
 
       deallog.depth_console (0);
 
       RunTimeParameters::Data_Storage data;
       data.read_data("parameter-file.prm");

       for (unsigned int k = 1; k <= 2; ++k)
      {
      std::cout
        << "===================================="
        << std::endl;

      std::cout
        << "Starting simulation "
        << k
        << std::endl;

      std::cout
        << "===================================="
        << std::endl;

      NSE::InitialCondition<2> exact_solution(k);

 
      
       NavierStokesProblem<2> flow_problem (exact_solution, data);
       flow_problem.run ();

     }
                                                                                                                      
 
     }
 
   catch (std::exception &exc)
     {
       std::cerr << std::endl << std::endl
                 << "----------------------------------------------------"
                 << std::endl;
       std::cerr << "Exception on processing: " << std::endl
                 << exc.what() << std::endl
                 << "Aborting!" << std::endl
                 << "----------------------------------------------------"
                 << std::endl;
 
       return 1;
     }
   catch (...)
     {
       std::cerr << std::endl << std::endl
                 << "----------------------------------------------------"
                 << std::endl;
       std::cerr << "Unknown exception!" << std::endl
                 << "Aborting!" << std::endl
                 << "----------------------------------------------------"
                 << std::endl;
       return 1;
     }
 
   return 0;
 }


